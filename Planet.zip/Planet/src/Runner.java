import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Runner {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(args[0]));

        HashMap<String, Planet> strPlanet = new HashMap<>();
        while(scanner.hasNext()) {
            String[] s = scanner.nextLine().split(";");

            strPlanet.put(s[0], new Planet(s));
        }

        ArrayList<Planet> gasGiants = findGasGiants(strPlanet);
        gasGiants.stream().sorted(Runner::compare).forEach(System.out::println);
    }

    public static ArrayList<Planet> findGasGiants(HashMap<String, Planet> stringPlanetHashMap) {
        ArrayList<Planet> gasGiants = new ArrayList<>();

        for (String key : stringPlanetHashMap.keySet()) {
            Planet p = stringPlanetHashMap.get(key);
            if (p.isGasGiant(p)){
                gasGiants.add(p);
            }
        }

        return gasGiants;
    }

    private static int compare(Planet o1, Planet o2) {
        int v = o1.getDiameter() - o2.getDiameter();
        if (!(v == 0)) return v;
        return (int) (o1.getDistanceFromSun() - o2.getDistanceFromSun());
    }
}