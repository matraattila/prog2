import java.util.Objects;

public class Planet {
    private String name;
    private int diameter;
    private double distanceFromSun;
    private double distanceFromMoon;
    private String matter;

    /**
     * A bolygó adatainak inicializálása
     * @param name Bolygó neve
     * @param diameter Bolygó átmérője
     * @param distanceFromSun Bolygó távolsága a naptól
     * @param distanceFromMoon Bolygó távolsága a holdtól
     * @param matter Bolygó anyaga
     */
    public Planet(String name, int diameter, double distanceFromSun, double distanceFromMoon, String matter) {
        this.name = name;
        this.diameter = diameter;
        this.distanceFromSun = distanceFromSun;
        this.distanceFromMoon = distanceFromMoon;
        this.matter = matter;
    }

    public Planet(String[] s) {
        this.name = s[0];
        this.diameter = Integer.parseInt(s[1]);
        this.distanceFromSun = Double.parseDouble(s[2]);
        this.distanceFromMoon = Double.parseDouble(s[3]);
        this.matter = s[4];
    }

    public String getName() {
        return name;
    }

    public int getDiameter() {
        return diameter;
    }

    /**
     * Egy bolygó naptól való távolságának lekérése
     * @return Bolygó távolsága a naptól
     */
    public double getDistanceFromSun() {
        return distanceFromSun;
    }

    public double getDistanceFromMoon() {
        return distanceFromMoon;
    }

    public String getMatter() {
        return matter;
    }

    // b
    public boolean isGasGiant(Planet p) {
        return p.matter.equals("gas") && p.diameter > 40_000;
    }

    public double getMaxPossibleDistanceFromPlanet(Planet other) {
        return this.distanceFromSun + other.distanceFromSun;
    }

    /**
     * Megvizsgálja hogy két bolygó neve megegyezik-e
     * @param o Planet típusú objektum
     * @return Két bolygó neve megegyezik-e
     */
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;

        Planet planet = (Planet) o;
        return Objects.equals(name, planet.name);
    }

    @Override
    public int hashCode() {
        int result = Objects.hashCode(name);
        result = 31 * result + diameter;
        result = 31 * result + Double.hashCode(distanceFromSun);
        result = 31 * result + Double.hashCode(distanceFromMoon);
        result = 31 * result + Objects.hashCode(matter);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Planet{");
        sb.append("name='").append(name).append('\'');
        sb.append(", diameter=").append(diameter);
        sb.append(", distanceFromSun=").append(distanceFromSun);
        sb.append(", distanceFromMoon=").append(distanceFromMoon);
        sb.append(", matter='").append(matter).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
