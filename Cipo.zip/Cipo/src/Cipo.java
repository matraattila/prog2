import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDate;

@JsonPropertyOrder({"modellszam", "meret", "szin", "evszak", "gyartasDatuma"})
public class Cipo {
    private String modellszam;
    private int meret;
    private String szin;
    private String evszak;

    @JsonFormat(pattern = "yyyy.MM.dd")
    private LocalDate gyartasDatuma;

    public Cipo() {

    }

    public String getModellszam() {
        return modellszam;
    }

    public int getMeret() {
        return meret;
    }

    public String getSzin() {
        return szin;
    }

    public String getEvszak() {
        return evszak;
    }

    public LocalDate getGyartasDatuma() {
        return gyartasDatuma;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Cipo{");
        sb.append("modellszam='").append(modellszam).append('\'');
        sb.append(", meret=").append(meret);
        sb.append(", szin='").append(szin).append('\'');
        sb.append(", evszak='").append(evszak).append('\'');
        sb.append(", gyartasDatuma=").append(gyartasDatuma);
        sb.append('}');
        return sb.toString();
    }
}
