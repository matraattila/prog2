import java.util.ArrayList;

public class Adatok {
    private ArrayList<Cipo> adatok = new ArrayList<>();

    public Adatok() {
    }

    public ArrayList<Cipo> getAdatok() {
        return adatok;
    }

    public void setAdatok(ArrayList<Cipo> adatok) {
        this.adatok = adatok;
    }
}
