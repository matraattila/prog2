import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;


import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {
        ObjectMapper om = new ObjectMapper();
        om.registerModule(new JavaTimeModule());

        Adatok adatok = om.readValue(new File("cipo.json"), Adatok.class);

        adatok.getAdatok().stream()
                .filter((cipo -> cipo.getMeret() <= 30 && cipo.getSzin().equals("fekete")))
        .forEach(cipo -> System.out.println(cipo.getMeret()));

        Optional<Cipo> minMeret = adatok.getAdatok().stream()
                .min((o1, o2) -> o1.getMeret() - o2.getMeret())
                .stream().findFirst();
        System.out.println(minMeret.get().getMeret());

        Map<String, List<Cipo>> evszakCipo = adatok.getAdatok().stream()
                .collect(Collectors.groupingBy(Cipo::getEvszak));

        evszakCipo.forEach((s, cipos) -> {
            System.out.println(s);
            cipos.forEach(System.out::println);
        });

    }

}