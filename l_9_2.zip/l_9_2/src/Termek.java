import java.time.LocalDate;

public class Termek {
    private String nev;
    private int ar;
    private String tipus;
    private String marka;
    private LocalDate keszult;

    public Termek(String nev, int ar, String tipus, String marka, LocalDate keszult) {
        this.nev = nev;
        this.ar = ar;
        this.tipus = tipus;
        this.marka = marka;
        this.keszult = keszult;
    }

    public Termek(String[] s) {
        this.nev = s[0];
        this.ar = Integer.parseInt(s[1]);
        this.tipus = s[2];
        this.marka = s[3];
        this.keszult = LocalDate.parse(s[4]);
    }

    public String getNev() {
        return nev;
    }

    public int getAr() {
        return ar;
    }

    public String getTipus() {
        return tipus;
    }

    public String getMarka() {
        return marka;
    }

    public LocalDate getKeszult() {
        return keszult;
    }


}
