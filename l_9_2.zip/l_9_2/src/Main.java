import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        // ======================================================================
        // Fájlból olvasás
        // Fontos hogy a fájl ne az <src> mappába legyen, hanem projekt szinten!
        // ======================================================================

        // 1. A fájl nevét közvetlen adjuk át
        Scanner sc = new Scanner(new File("termek.txt"));
        // 2. A feladat kérheti hogy a fájl nevét paraméterként kell adjuk meg, ekkor
        // az <args> tombből érhetjük el a fájl nevét: args[0]
        // Scanner sc = new Scanner(new File(args[0]));

        // Amíg van új sor olvassunk be
        ArrayList<Termek> termekek = new ArrayList<>();
        while(sc.hasNextLine()) {
            // Az új sor
            String sor = sc.nextLine();
            // Az új sor felszeletelve az elválasztó karakter mentén
            String[] s = sor.split(";");

            // Új példány létrehozása az adott sor adataiból.
            // (Az értékadást a <String[] s> paraméterű konstruktor végzi)
            Termek t = new Termek(s);
            termekek.add(t);
        }


        // ===========
        // Fájlba írás
        termekek.stream().
                filter(t -> t.getNev().equals("Tej")).
                forEach(x -> System.out.println(x.getNev()));

        // Write to file
        try(FileWriter fw = new FileWriter(new File("out.txt")))
        {
            for (Termek termek : termekek) {
                fw.write(termek.getNev() + "\n");
            }

            fw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
